Component({
  props: {
    product: {
      image: "",
      name: "",
      price: "",
      description: "",
      quantity: 0
    }
  }
})