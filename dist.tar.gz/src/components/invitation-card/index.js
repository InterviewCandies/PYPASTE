Component({
  methods: {
    onTap() {
      my.navigateTo({url: "pages/invitation-details/index"})
    }
  }
})