Component({
  props: {
    friend: {
      name: "",
      phone: "",
      avatar: ""
    }
  }
})