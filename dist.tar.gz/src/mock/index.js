const products = {
  "name" : "sdfsf"
}

module.export = products;