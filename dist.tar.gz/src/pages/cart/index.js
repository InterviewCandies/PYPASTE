Page({
  onLoad() {
  },
  onImport() {
    my.navigateTo({url: 'pages/editor/index'})
  }
})