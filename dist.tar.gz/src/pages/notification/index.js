Page({
  data: {
    notifications: [{
      content: "Hồng Nhi đã từ chối lời mời của bạn",
      status: "REJECTED",
      date: "20/07/2021"
    },
    {
      content: "Thọ Bùi đã chấp nhận lời mời của bạn",
      status: "ACCEPTED",
      date: "18/07/2021"
    },
    {
      content: "Minh Châu đã từ chối lời mời của bạn",
      status: "ACCEPTED",
      date: "15/07/2021"
    },
    {
      content: "Thịnh Nguyễn đã chấp nhận lời mời của bạn",
      status: "REJECTED",
      date: "10/07/2021"
    },
     {
      content: "Bảo Nguyễn đã chấp nhận lời mời của bạn",
      status: "ACCEPTED",
      date: "10/07/2021"
    },
     {
      content: "Vĩnh Trương đã chấp nhận lời mời của bạn",
      status: "REJECTED",
      date: "09/07/2021"
    }]
  }
})