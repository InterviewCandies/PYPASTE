Page({
  data: {
    store: {
      url: "https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?ixid=MnwxMjA3fDB8MHxzZWFyY2h8N3x8c3RvcmV8ZW58MHx8MHx8&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
      name: "Tran le Hong nhi",
      id: "adsad",
      phone: "3423420",
      email: "tlhni@gmail.com",
      location: "Hồ Chí Minh, Việt Nam"
    }
  }
})